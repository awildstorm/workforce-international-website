/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      fontFamily: {
        sans: ['Poppins', 'Montserrat', 'system-ui', 'sans-serif'],
      },
      colors: {
        'navy': {
          900: '#002F6C',
          800: '#003d7a',
          700: '#004a88',
          600: '#005796',
          500: '#0064a4',
          400: '#0071b2',
          300: '#007ec0',
          200: '#008bce',
          100: '#0098dc',
        },
        'cyan': {
          600: '#00AEEF',
          500: '#1ab8f0',
          400: '#33c2f1',
          300: '#4dccf2',
          200: '#66d6f3',
          100: '#80e0f4',
          50: '#e6f7fe',
        },
        'light-gray': '#F5F7FA',
        'dark-gray': '#333333',
      },
    },
  },
  plugins: [],
};