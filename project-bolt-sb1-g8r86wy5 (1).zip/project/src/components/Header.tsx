import React, { useState } from 'react';
import { Menu, X, Phone, Mail, MapPin, ChevronDown } from 'lucide-react';

const Header: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isServicesOpen, setIsServicesOpen] = useState(false);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
    setIsMenuOpen(false);
  };

  return (
    <header className="bg-white shadow-lg sticky top-0 z-50">
      {/* Top Contact Bar */}
      <div className="bg-navy-900 text-white py-2">
        <div className="container mx-auto px-4">
          <div className="flex flex-wrap justify-between items-center text-sm">
            <div className="flex items-center space-x-6">
              <div className="flex items-center space-x-2">
                <Phone className="h-4 w-4" />
                <span>+1 (914) 369-0389</span>
              </div>
              <div className="flex items-center space-x-2">
                <Mail className="h-4 w-4" />
                <span>recruitment@workforceinternational.agency</span>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <MapPin className="h-4 w-4" />
              <span>New York, NY | Nairobi, Kenya | Thimphu, Bhutan</span>
            </div>
          </div>
        </div>
      </div>

      {/* Main Navigation */}
      <nav className="container mx-auto px-4 py-4">
        <div className="flex justify-between items-center">
          <div className="flex items-center space-x-3">
            <div className="bg-cyan-600 text-white p-3 rounded-lg">
              <span className="font-bold text-2xl">WI</span>
            </div>
            <div>
              <h1 className="text-2xl font-bold text-navy-900">Workforce International</h1>
              <p className="text-sm text-gray-600 font-medium">Limited</p>
            </div>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden lg:flex items-center space-x-8">
            <button onClick={() => scrollToSection('home')} className="text-gray-700 hover:text-cyan-600 transition-colors font-semibold text-lg">
              Home
            </button>
            
            <div className="relative group">
              <button 
                className="text-gray-700 hover:text-cyan-600 transition-colors font-semibold text-lg flex items-center"
                onMouseEnter={() => setIsServicesOpen(true)}
                onMouseLeave={() => setIsServicesOpen(false)}
              >
                Services
                <ChevronDown className="ml-1 h-4 w-4" />
              </button>
              
              {isServicesOpen && (
                <div 
                  className="absolute top-full left-0 mt-2 w-64 bg-white shadow-xl rounded-lg border border-gray-200 py-4 z-50"
                  onMouseEnter={() => setIsServicesOpen(true)}
                  onMouseLeave={() => setIsServicesOpen(false)}
                >
                  <button onClick={() => scrollToSection('services')} className="block w-full text-left px-6 py-2 text-gray-700 hover:bg-cyan-50 hover:text-cyan-600 transition-colors">
                    All Services
                  </button>
                  <button onClick={() => scrollToSection('job-categories')} className="block w-full text-left px-6 py-2 text-gray-700 hover:bg-cyan-50 hover:text-cyan-600 transition-colors">
                    Job Categories
                  </button>
                  <button onClick={() => scrollToSection('payment-info')} className="block w-full text-left px-6 py-2 text-gray-700 hover:bg-cyan-50 hover:text-cyan-600 transition-colors">
                    Payment Information
                  </button>
                </div>
              )}
            </div>

            <button onClick={() => scrollToSection('about')} className="text-gray-700 hover:text-cyan-600 transition-colors font-semibold text-lg">
              About
            </button>
            <button onClick={() => scrollToSection('contact')} className="text-gray-700 hover:text-cyan-600 transition-colors font-semibold text-lg">
              Contact
            </button>
            
            <button 
              onClick={() => scrollToSection('job-categories')}
              className="bg-cyan-600 text-white px-8 py-3 rounded-lg hover:bg-cyan-700 transition-colors font-semibold text-lg shadow-lg"
            >
              Find Jobs
            </button>
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={toggleMenu}
            className="lg:hidden text-gray-700 hover:text-cyan-600 transition-colors"
          >
            {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="lg:hidden mt-4 py-4 border-t border-gray-200">
            <div className="flex flex-col space-y-4">
              <button onClick={() => scrollToSection('home')} className="text-gray-700 hover:text-cyan-600 transition-colors font-semibold text-left">
                Home
              </button>
              <button onClick={() => scrollToSection('services')} className="text-gray-700 hover:text-cyan-600 transition-colors font-semibold text-left">
                Services
              </button>
              <button onClick={() => scrollToSection('about')} className="text-gray-700 hover:text-cyan-600 transition-colors font-semibold text-left">
                About
              </button>
              <button onClick={() => scrollToSection('job-categories')} className="text-gray-700 hover:text-cyan-600 transition-colors font-semibold text-left">
                Job Categories
              </button>
              <button onClick={() => scrollToSection('contact')} className="text-gray-700 hover:text-cyan-600 transition-colors font-semibold text-left">
                Contact
              </button>
              <button 
                onClick={() => scrollToSection('job-categories')}
                className="bg-cyan-600 text-white px-6 py-3 rounded-lg hover:bg-cyan-700 transition-colors font-semibold w-full mt-4"
              >
                Find Jobs
              </button>
            </div>
          </div>
        )}
      </nav>
    </header>
  );
};

export default Header;