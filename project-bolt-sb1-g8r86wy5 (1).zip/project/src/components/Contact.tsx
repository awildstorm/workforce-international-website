import React, { useState } from 'react';
import { 
  Phone, 
  Mail, 
  MapPin, 
  Clock, 
  Send,
  CheckCircle,
  Globe,
  MessageSquare
} from 'lucide-react';

const Contact: React.FC = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    company: '',
    phone: '',
    service: '',
    message: ''
  });

  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle form submission here
    setIsSubmitted(true);
    setTimeout(() => setIsSubmitted(false), 5000);
  };

  const offices = [
    {
      city: "New York",
      address: "123 Business Ave, Suite 500",
      phone: "+1 (555) 123-4567",
      email: "ny@workforceinternational.agency"
    },
    {
      city: "London",
      address: "45 Corporate Street, Floor 10",
      phone: "+44 20 7123 4567",
      email: "london@workforceinternational.agency"
    },
    {
      city: "Singapore",
      address: "88 Business Hub, Tower A",
      phone: "+65 6123 4567",
      email: "singapore@workforceinternational.agency"
    }
  ];

  return (
    <section id="contact" className="py-24 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-20">
          <div className="inline-block bg-cyan-100 text-cyan-600 px-6 py-3 rounded-full text-sm font-bold mb-6 uppercase tracking-wide">
            Get In Touch
          </div>
          <h2 className="text-5xl lg:text-6xl font-bold text-navy-900 mb-8">
            Ready to Transform
            <span className="block text-cyan-600">Your Workforce?</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-4xl mx-auto leading-relaxed">
            Contact our experts today to discuss your staffing needs and discover 
            how we can help you build a world-class team.
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-16">
          {/* Contact Form */}
          <div className="lg:col-span-2">
            <div className="bg-light-gray rounded-3xl p-10 shadow-xl">
              <h3 className="text-3xl font-bold text-navy-900 mb-8">Send Us a Message</h3>
              
              {isSubmitted ? (
                <div className="bg-green-50 border border-green-200 rounded-2xl p-8 text-center">
                  <CheckCircle className="h-16 w-16 text-green-500 mx-auto mb-6" />
                  <h4 className="text-2xl font-bold text-green-800 mb-4">Message Sent Successfully!</h4>
                  <p className="text-green-600 text-lg">We'll get back to you within 24 hours.</p>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-8">
                  <div className="grid md:grid-cols-2 gap-8">
                    <div>
                      <label htmlFor="name" className="block text-sm font-bold text-gray-700 mb-3 uppercase tracking-wide">
                        Full Name *
                      </label>
                      <input
                        type="text"
                        id="name"
                        name="name"
                        required
                        value={formData.name}
                        onChange={handleChange}
                        className="w-full px-6 py-4 border border-gray-300 rounded-xl focus:ring-2 focus:ring-cyan-500 focus:border-transparent transition-colors text-lg"
                        placeholder="Your full name"
                      />
                    </div>
                    <div>
                      <label htmlFor="email" className="block text-sm font-bold text-gray-700 mb-3 uppercase tracking-wide">
                        Email Address *
                      </label>
                      <input
                        type="email"
                        id="email"
                        name="email"
                        required
                        value={formData.email}
                        onChange={handleChange}
                        className="w-full px-6 py-4 border border-gray-300 rounded-xl focus:ring-2 focus:ring-cyan-500 focus:border-transparent transition-colors text-lg"
                        placeholder="your.email@company.com"
                      />
                    </div>
                  </div>

                  <div className="grid md:grid-cols-2 gap-8">
                    <div>
                      <label htmlFor="company" className="block text-sm font-bold text-gray-700 mb-3 uppercase tracking-wide">
                        Company Name
                      </label>
                      <input
                        type="text"
                        id="company"
                        name="company"
                        value={formData.company}
                        onChange={handleChange}
                        className="w-full px-6 py-4 border border-gray-300 rounded-xl focus:ring-2 focus:ring-cyan-500 focus:border-transparent transition-colors text-lg"
                        placeholder="Your company"
                      />
                    </div>
                    <div>
                      <label htmlFor="phone" className="block text-sm font-bold text-gray-700 mb-3 uppercase tracking-wide">
                        Phone Number
                      </label>
                      <input
                        type="tel"
                        id="phone"
                        name="phone"
                        value={formData.phone}
                        onChange={handleChange}
                        className="w-full px-6 py-4 border border-gray-300 rounded-xl focus:ring-2 focus:ring-cyan-500 focus:border-transparent transition-colors text-lg"
                        placeholder="+1 (555) 123-4567"
                      />
                    </div>
                  </div>

                  <div>
                    <label htmlFor="service" className="block text-sm font-bold text-gray-700 mb-3 uppercase tracking-wide">
                      Service Interested In
                    </label>
                    <select
                      id="service"
                      name="service"
                      value={formData.service}
                      onChange={handleChange}
                      className="w-full px-6 py-4 border border-gray-300 rounded-xl focus:ring-2 focus:ring-cyan-500 focus:border-transparent transition-colors text-lg"
                    >
                      <option value="">Select a service</option>
                      <option value="permanent">Permanent Recruitment</option>
                      <option value="temporary">Temporary Staffing</option>
                      <option value="management">Workforce Management</option>
                      <option value="consulting">HR Consulting</option>
                      <option value="global">Global Expansion</option>
                      <option value="other">Other</option>
                    </select>
                  </div>

                  <div>
                    <label htmlFor="message" className="block text-sm font-bold text-gray-700 mb-3 uppercase tracking-wide">
                      Message *
                    </label>
                    <textarea
                      id="message"
                      name="message"
                      required
                      rows={5}
                      value={formData.message}
                      onChange={handleChange}
                      className="w-full px-6 py-4 border border-gray-300 rounded-xl focus:ring-2 focus:ring-cyan-500 focus:border-transparent transition-colors resize-none text-lg"
                      placeholder="Tell us about your staffing needs..."
                    ></textarea>
                  </div>

                  <button
                    type="submit"
                    className="bg-cyan-600 text-white px-10 py-5 rounded-xl font-bold text-lg hover:bg-cyan-700 transition-colors flex items-center justify-center w-full group shadow-lg"
                  >
                    Send Message
                    <Send className="ml-3 h-6 w-6 group-hover:translate-x-1 transition-transform" />
                  </button>
                </form>
              )}
            </div>
          </div>

          {/* Contact Information */}
          <div className="space-y-10">
            <div className="bg-cyan-50 rounded-3xl p-10 shadow-xl">
              <h3 className="text-2xl font-bold text-navy-900 mb-8">Contact Information</h3>
              
              <div className="space-y-8">
                <div className="flex items-start space-x-5">
                  <div className="bg-cyan-600 text-white p-4 rounded-xl">
                    <Phone className="h-5 w-5" />
                  </div>
                  <div>
                    <h4 className="font-bold text-navy-900 text-lg">Phone</h4>
                    <p className="text-gray-600 text-lg">+1 (914) 369-0389</p>
                    <p className="text-sm text-gray-500">Mon-Fri 8AM-6PM EST</p>
                  </div>
                </div>

                <div className="flex items-start space-x-5">
                  <div className="bg-cyan-600 text-white p-4 rounded-xl">
                    <Mail className="h-5 w-5" />
                  </div>
                  <div>
                    <h4 className="font-bold text-navy-900 text-lg">Email</h4>
                    <p className="text-gray-600 text-lg">recruitment@workforceinternational.agency</p>
                    <p className="text-sm text-gray-500">We respond within 24 hours</p>
                  </div>
                </div>

                <div className="flex items-start space-x-5">
                  <div className="bg-cyan-600 text-white p-4 rounded-xl">
                    <MapPin className="h-5 w-5" />
                  </div>
                  <div>
                    <h4 className="font-bold text-navy-900 text-lg">Office Location</h4>
                    <p className="text-gray-600 text-lg">724 Lexington Avenue</p>
                    <p className="text-gray-600 text-lg">New York, NY 10022</p>
                    <p className="text-gray-600 text-lg">United States</p>
                  </div>
                </div>

                <div className="flex items-start space-x-5">
                  <div className="bg-cyan-600 text-white p-4 rounded-xl">
                    <MessageSquare className="h-5 w-5" />
                  </div>
                  <div>
                    <h4 className="font-bold text-navy-900 text-lg">Live Chat</h4>
                    <p className="text-gray-600 text-lg">Available on our website</p>
                    <p className="text-sm text-gray-500">Instant support during business hours</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-navy-900 text-white rounded-3xl p-10 shadow-xl">
              <h3 className="text-2xl font-bold mb-8">Global Offices</h3>
              <div className="space-y-8">
                <div className="border-b border-gray-700 pb-6">
                  <h4 className="font-bold text-cyan-400 mb-3 text-lg">New York (Main Office)</h4>
                  <p className="text-gray-300 mb-1">724 Lexington Avenue</p>
                  <p className="text-gray-300 mb-1">New York, NY 10022, United States</p>
                  <p className="text-gray-300 mb-1">+1 (914) 369-0389</p>
                  <p className="text-gray-300">recruitment@workforceinternational.agency</p>
                </div>
                <div className="border-b border-gray-700 pb-6">
                  <h4 className="font-bold text-cyan-400 mb-3 text-lg">Asia Partnership</h4>
                  <p className="text-gray-300 mb-1">UC Associates</p>
                  <p className="text-gray-300">Bhutan, Cheda, and Lhaki Building in Thimphu</p>
                </div>
                <div>
                  <h4 className="font-bold text-cyan-400 mb-3 text-lg">Africa Partnership</h4>
                  <p className="text-gray-300 mb-1">PATRICK, TEDDY & PARTNERS</p>
                  <p className="text-gray-300">Nairobi, Kenya</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;