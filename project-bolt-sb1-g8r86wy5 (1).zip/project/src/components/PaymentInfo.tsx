import React from 'react';
import { CreditCard, Smartphone, Shield, CheckCircle, AlertCircle } from 'lucide-react';

const PaymentInfo: React.FC = () => {
  return (
    <section id="payment-info" className="py-24 bg-light-gray">
      <div className="container mx-auto px-4">
        <div className="text-center mb-20">
          <div className="inline-block bg-green-100 text-green-600 px-6 py-3 rounded-full text-sm font-bold mb-6 uppercase tracking-wide">
            Payment Information
          </div>
          <h2 className="text-5xl lg:text-6xl font-bold text-navy-900 mb-8">
            Simple & Secure
            <span className="block text-green-600">Payment Process</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-4xl mx-auto leading-relaxed">
            Simple and secure payment options for your registration cost.
          </p>
        </div>

        <div className="max-w-6xl mx-auto">
          <div className="grid md:grid-cols-2 gap-8">
            {/* M-Pesa Payment */}
            <div className="bg-white border border-green-200 rounded-3xl p-10 shadow-xl">
              <div className="flex items-center space-x-6 mb-8">
                <div className="bg-green-600 text-white p-4 rounded-2xl">
                  <Smartphone className="h-10 w-10" />
                </div>
                <div>
                  <h3 className="text-3xl font-bold text-navy-900">Pay via M-Pesa</h3>
                  <p className="text-green-600 font-bold text-lg">Quick & Convenient</p>
                </div>
              </div>

              <div className="space-y-6">
                <div className="flex items-start space-x-4">
                  <div className="bg-green-600 text-white rounded-full w-8 h-8 flex items-center justify-center text-sm font-bold mt-1">
                    1
                  </div>
                  <div>
                    <p className="font-bold text-navy-900 text-lg">Go to Lipa na M-Pesa</p>
                    <p className="text-gray-600">Access the payment menu on your phone</p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="bg-green-600 text-white rounded-full w-8 h-8 flex items-center justify-center text-sm font-bold mt-1">
                    2
                  </div>
                  <div>
                    <p className="font-bold text-navy-900 text-lg">Select "Buy Goods"</p>
                    <p className="text-gray-600">Choose the buy goods option</p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="bg-green-600 text-white rounded-full w-8 h-8 flex items-center justify-center text-sm font-bold mt-1">
                    3
                  </div>
                  <div>
                    <p className="font-bold text-navy-900 text-lg">Pay USD 50</p>
                    <p className="text-gray-600">Enter the registration cost amount</p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="bg-green-600 text-white rounded-full w-8 h-8 flex items-center justify-center text-sm font-bold mt-1">
                    4
                  </div>
                  <div>
                    <p className="font-bold text-navy-900 text-lg">Till Number: <span className="text-green-600 font-bold text-2xl">493969</span></p>
                    <p className="text-gray-600">Use this till number for payment</p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="bg-green-600 text-white rounded-full w-8 h-8 flex items-center justify-center text-sm font-bold mt-1">
                    5
                  </div>
                  <div>
                    <p className="font-bold text-navy-900 text-lg">Keep Confirmation Code</p>
                    <p className="text-gray-600">Save the code for verification purposes</p>
                  </div>
                </div>
              </div>

              <div className="mt-8 p-6 bg-green-50 rounded-2xl border border-green-200">
                <div className="flex items-center space-x-3 mb-3">
                  <Shield className="h-5 w-5 text-green-600" />
                  <span className="font-bold text-navy-900 text-lg">Secure Payment</span>
                </div>
                <p className="text-gray-600">
                  All M-Pesa transactions are encrypted and secure. Your payment information is protected.
                </p>
              </div>
            </div>

            {/* Alternative Payment Methods */}
            <div className="bg-white border border-cyan-200 rounded-3xl p-10 shadow-xl">
              <div className="flex items-center space-x-6 mb-8">
                <div className="bg-cyan-600 text-white p-4 rounded-2xl">
                  <CreditCard className="h-10 w-10" />
                </div>
                <div>
                  <h3 className="text-3xl font-bold text-navy-900">Other Payment Options</h3>
                  <p className="text-cyan-600 font-bold text-lg">Multiple Methods Available</p>
                </div>
              </div>

              <div className="space-y-6">
                <div className="p-6 bg-cyan-50 rounded-2xl border border-cyan-200">
                  <h4 className="font-bold text-navy-900 mb-3 text-lg">Online Payment</h4>
                  <p className="text-gray-600 mb-4">
                    Secure online payment via credit/debit card
                  </p>
                  <button className="text-cyan-600 font-bold hover:text-cyan-700 transition-colors">
                    Pay Online →
                  </button>
                </div>
              </div>

              <div className="mt-8 p-6 bg-cyan-50 rounded-2xl border border-cyan-200">
                <div className="flex items-center space-x-3 mb-3">
                  <CheckCircle className="h-5 w-5 text-cyan-600" />
                  <span className="font-bold text-navy-900 text-lg">Registration Cost</span>
                </div>
                <p className="text-3xl font-bold text-cyan-600 mb-2">USD 50</p>
                <p className="text-gray-600">
                  One-time registration cost for processing your application
                </p>
              </div>
            </div>
          </div>

          <div className="mt-16 text-center">
            <div className="bg-yellow-50 border border-yellow-200 rounded-3xl p-10 max-w-4xl mx-auto">
              <div className="flex items-center justify-center space-x-3 mb-6">
                <AlertCircle className="h-5 w-5 text-yellow-600" />
                <h4 className="font-bold text-navy-900 text-xl">Important Note</h4>
              </div>
              <p className="text-gray-600 text-lg leading-relaxed">
                Please keep your confirmation code safe and provide it when submitting your application. 
                This helps us verify your payment and process your registration quickly.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default PaymentInfo;