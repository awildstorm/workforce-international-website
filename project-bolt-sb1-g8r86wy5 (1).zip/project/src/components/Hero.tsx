import React from 'react';
import { ArrowRight, Users, Globe, TrendingUp, CheckCircle } from 'lucide-react';

const Hero: React.FC = () => {
  return (
    <section id="home" className="relative bg-gradient-to-br from-navy-900 via-navy-800 to-navy-700 text-white overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute inset-0 bg-gradient-to-r from-cyan-400 to-transparent"></div>
      </div>
      
      <div className="container mx-auto px-4 py-20 lg:py-32 relative z-10">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <div className="space-y-8">
            <div className="space-y-6">
              <div className="inline-block bg-cyan-600 bg-opacity-20 backdrop-blur-sm px-6 py-3 rounded-full text-sm font-semibold border border-cyan-400 border-opacity-30">
                🌍 Global Workforce Solutions
              </div>
              
              <h1 className="text-5xl lg:text-7xl font-bold leading-tight">
                Your Gateway to
                <span className="block text-cyan-400">Global Talent</span>
              </h1>
              
              <p className="text-xl lg:text-2xl text-gray-200 leading-relaxed max-w-2xl">
                Workforce International Limited specializes in connecting exceptional talent 
                across Asia, East, and Central Africa with worldwide employment opportunities.
              </p>
            </div>

            {/* Key Benefits */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 my-8">
              <div className="flex items-center space-x-3">
                <CheckCircle className="h-6 w-6 text-cyan-400 flex-shrink-0" />
                <span className="text-lg">Ethical Recruitment</span>
              </div>
              <div className="flex items-center space-x-3">
                <CheckCircle className="h-6 w-6 text-cyan-400 flex-shrink-0" />
                <span className="text-lg">Legal Compliance</span>
              </div>
              <div className="flex items-center space-x-3">
                <CheckCircle className="h-6 w-6 text-cyan-400 flex-shrink-0" />
                <span className="text-lg">USD 50 Registration</span>
              </div>
              <div className="flex items-center space-x-3">
                <CheckCircle className="h-6 w-6 text-cyan-400 flex-shrink-0" />
                <span className="text-lg">Global Partnerships</span>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-6">
              <button 
                onClick={() => document.getElementById('job-categories')?.scrollIntoView({ behavior: 'smooth' })}
                className="bg-cyan-600 text-white px-10 py-5 rounded-xl font-bold text-lg hover:bg-cyan-700 transition-all duration-300 flex items-center justify-center group shadow-2xl"
              >
                Browse Job Categories
                <ArrowRight className="ml-3 h-6 w-6 group-hover:translate-x-1 transition-transform" />
              </button>
              <button 
                onClick={() => document.getElementById('about')?.scrollIntoView({ behavior: 'smooth' })}
                className="border-2 border-white text-white px-10 py-5 rounded-xl font-bold text-lg hover:bg-white hover:text-navy-900 transition-all duration-300"
              >
                Learn More
              </button>
            </div>
          </div>
          
          <div className="relative">
            <div className="relative z-10">
              <img 
                src="https://images.pexels.com/photos/3184465/pexels-photo-3184465.jpeg?auto=compress&cs=tinysrgb&w=800"
                alt="Professional team collaboration"
                className="rounded-3xl shadow-2xl w-full"
              />
              
              {/* Floating Stats Card */}
              <div className="absolute -bottom-8 -left-8 bg-white text-gray-800 p-8 rounded-2xl shadow-2xl border border-gray-100">
                <div className="flex items-center space-x-4">
                  <div className="bg-cyan-100 p-4 rounded-xl">
                    <Users className="h-8 w-8 text-cyan-600" />
                  </div>
                  <div>
                    <p className="text-3xl font-bold text-cyan-600">50K+</p>
                    <p className="text-sm text-gray-600 font-medium">Successful Placements</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Background Decoration */}
            <div className="absolute -top-4 -right-4 w-72 h-72 bg-cyan-600 bg-opacity-20 rounded-full blur-3xl"></div>
            <div className="absolute -bottom-8 -right-8 w-96 h-96 bg-cyan-400 bg-opacity-10 rounded-full blur-3xl"></div>
          </div>
        </div>

        {/* Stats Section */}
        <div className="mt-24 grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="text-center group">
            <div className="bg-cyan-600 bg-opacity-20 backdrop-blur-sm p-6 rounded-2xl w-20 h-20 mx-auto mb-6 flex items-center justify-center group-hover:bg-opacity-30 transition-all duration-300">
              <Globe className="h-10 w-10 text-cyan-400" />
            </div>
            <h3 className="text-4xl font-bold mb-3">3</h3>
            <p className="text-xl text-gray-200">Key Regions</p>
            <p className="text-sm text-gray-400 mt-2">Asia, East & Central Africa</p>
          </div>
          
          <div className="text-center group">
            <div className="bg-cyan-600 bg-opacity-20 backdrop-blur-sm p-6 rounded-2xl w-20 h-20 mx-auto mb-6 flex items-center justify-center group-hover:bg-opacity-30 transition-all duration-300">
              <Users className="h-10 w-10 text-cyan-400" />
            </div>
            <h3 className="text-4xl font-bold mb-3">10K+</h3>
            <p className="text-xl text-gray-200">Active Candidates</p>
            <p className="text-sm text-gray-400 mt-2">Ready for placement</p>
          </div>
          
          <div className="text-center group">
            <div className="bg-cyan-600 bg-opacity-20 backdrop-blur-sm p-6 rounded-2xl w-20 h-20 mx-auto mb-6 flex items-center justify-center group-hover:bg-opacity-30 transition-all duration-300">
              <TrendingUp className="h-10 w-10 text-cyan-400" />
            </div>
            <h3 className="text-4xl font-bold mb-3">98%</h3>
            <p className="text-xl text-gray-200">Success Rate</p>
            <p className="text-sm text-gray-400 mt-2">Client satisfaction</p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;