import React from 'react';
import { 
  Users, 
  Search, 
  Building, 
  Clock, 
  Shield, 
  Target,
  ArrowRight,
  CheckCircle,
  Globe,
  Award
} from 'lucide-react';

const Services: React.FC = () => {
  const mainServices = [
    {
      icon: <Users className="h-12 w-12" />,
      title: "Permanent Recruitment",
      description: "Full-time permanent staff placement across all industries and skill levels with comprehensive screening.",
      features: ["Executive Search", "Mid-Level Positions", "Entry-Level Recruitment", "Specialized Roles"],
      color: "bg-blue-50 border-blue-200 text-blue-600"
    },
    {
      icon: <Clock className="h-12 w-12" />,
      title: "Temporary Staffing",
      description: "Flexible temporary workforce solutions for short-term projects and seasonal business needs.",
      features: ["Project-Based Staff", "Seasonal Workers", "Contract Positions", "Interim Management"],
      color: "bg-green-50 border-green-200 text-green-600"
    },
    {
      icon: <Building className="h-12 w-12" />,
      title: "Workforce Management",
      description: "Comprehensive workforce planning and management services for optimal productivity and efficiency.",
      features: ["Staff Scheduling", "Performance Management", "Training Programs", "Compliance Management"],
      color: "bg-purple-50 border-purple-200 text-purple-600"
    }
  ];

  const additionalServices = [
    {
      icon: <Search className="h-8 w-8" />,
      title: "Talent Acquisition",
      description: "Strategic talent acquisition consulting to build high-performing teams.",
      features: ["Recruitment Strategy", "Candidate Sourcing", "Skills Assessment"]
    },
    {
      icon: <Shield className="h-8 w-8" />,
      title: "HR Consulting",
      description: "Expert HR consulting services to optimize your human resources operations.",
      features: ["HR Audits", "Policy Development", "Employee Relations"]
    },
    {
      icon: <Target className="h-8 w-8" />,
      title: "Global Expansion",
      description: "Support for international business expansion with local workforce expertise.",
      features: ["Market Entry Support", "Local Compliance", "Cultural Integration"]
    }
  ];

  return (
    <section id="services" className="py-24 bg-light-gray">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-20">
          <div className="inline-block bg-cyan-100 text-cyan-600 px-6 py-3 rounded-full text-sm font-bold mb-6 uppercase tracking-wide">
            Our Services
          </div>
          <h2 className="text-5xl lg:text-6xl font-bold text-navy-900 mb-8">
            Comprehensive Workforce
            <span className="block text-cyan-600">Solutions</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-4xl mx-auto leading-relaxed">
            From permanent placements to temporary staffing, we provide end-to-end 
            workforce solutions tailored to your business needs. Our registration cost is USD 50.
          </p>
        </div>

        {/* Main Services */}
        <div className="grid lg:grid-cols-3 gap-8 mb-16">
          {mainServices.map((service, index) => (
            <div 
              key={index} 
              className="bg-white rounded-3xl p-10 shadow-xl hover:shadow-2xl transition-all duration-500 group hover:-translate-y-2 border border-gray-100"
            >
              <div className={`${service.color} p-6 rounded-2xl w-fit mb-8 group-hover:scale-110 transition-transform duration-300`}>
                {service.icon}
              </div>
              
              <h3 className="text-2xl font-bold text-navy-900 mb-6">{service.title}</h3>
              <p className="text-gray-600 mb-8 text-lg leading-relaxed">{service.description}</p>
              
              <ul className="space-y-3 mb-8">
                {service.features.map((feature, featureIndex) => (
                  <li key={featureIndex} className="flex items-center text-gray-600">
                    <CheckCircle className="h-5 w-5 text-green-500 mr-3 flex-shrink-0" />
                    <span className="font-medium">{feature}</span>
                  </li>
                ))}
              </ul>

              <button className="text-cyan-600 font-bold flex items-center hover:text-cyan-700 transition-colors group text-lg">
                Learn More
                <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
              </button>
            </div>
          ))}
        </div>

        {/* Additional Services */}
        <div className="bg-white rounded-3xl p-12 shadow-xl">
          <div className="text-center mb-12">
            <h3 className="text-3xl font-bold text-navy-900 mb-4">Additional Services</h3>
            <p className="text-xl text-gray-600">Specialized solutions for your unique business needs</p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {additionalServices.map((service, index) => (
              <div key={index} className="text-center group">
                <div className="bg-cyan-100 text-cyan-600 p-4 rounded-2xl w-fit mx-auto mb-6 group-hover:bg-cyan-600 group-hover:text-white transition-colors duration-300">
                  {service.icon}
                </div>
                <h4 className="text-xl font-bold text-navy-900 mb-4">{service.title}</h4>
                <p className="text-gray-600 mb-4">{service.description}</p>
                
                <ul className="space-y-2">
                  {service.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="text-sm text-gray-500">
                      • {feature}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>

        {/* CTA Section */}
        <div className="text-center mt-16">
          <div className="bg-gradient-to-r from-navy-900 to-navy-800 rounded-3xl p-12 text-white">
            <div className="flex items-center justify-center mb-6">
              <Globe className="h-12 w-12 text-cyan-400 mr-4" />
              <Award className="h-12 w-12 text-cyan-400" />
            </div>
            <h3 className="text-3xl font-bold mb-4">Ready to Transform Your Workforce?</h3>
            <p className="text-xl text-gray-300 mb-8 max-w-2xl mx-auto">
              Join thousands of satisfied clients who trust us with their staffing needs
            </p>
            <button 
              onClick={() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' })}
              className="bg-cyan-600 text-white px-10 py-4 rounded-xl font-bold text-lg hover:bg-cyan-700 transition-colors shadow-lg"
            >
              Get Started Today
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Services;