import React from 'react';
import { Award, Globe, Users, TrendingUp, Heart, Lightbulb, Scale, MapPin } from 'lucide-react';

const About: React.FC = () => {
  const values = [
    {
      icon: <Heart className="h-6 w-6" />,
      title: "Integrity",
      description: "We conduct business with the highest ethical standards and transparency."
    },
    {
      icon: <Lightbulb className="h-6 w-6" />,
      title: "Innovation",
      description: "We embrace new technologies and methodologies to deliver better results."
    },
    {
      icon: <Users className="h-6 w-6" />,
      title: "Partnership",
      description: "We build lasting relationships based on trust and mutual success."
    },
    {
      icon: <Award className="h-6 w-6" />,
      title: "Excellence",
      description: "We strive for excellence in every service we provide to our clients."
    }
  ];

  const collaborations = [
    {
      region: "Asia",
      partner: "UC Associates",
      location: "Bhutan, Cheda, and Lhaki Building in Thimphu",
      description: "Comprehensive legal consultations for overseas job opportunities, ensuring adherence to local legal requirements."
    },
    {
      region: "East and Central Africa",
      partner: "PATRICK, TEDDY & PARTNERS",
      location: "Nairobi, Kenya",
      description: "Expert legal consultations for overseas job placements, operating within regional legal frameworks."
    }
  ];

  return (
    <section id="about" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <div className="inline-block bg-cyan-100 text-cyan-600 px-4 py-2 rounded-full text-sm font-medium mb-4">
            About Us
          </div>
          <h2 className="text-4xl font-bold text-navy-900 mb-6">
            Company Overview
          </h2>
        </div>

        <div className="grid lg:grid-cols-2 gap-16 items-start">
          <div>
            <p className="text-lg text-gray-600 mb-6 leading-relaxed">
              At Workforce International Limited, we have honed our expertise in providing 
              specialized labor workforce solutions across Asia, East, and Central Africa. 
              With our deep commitment to ethical recruitment, we are proud to be a trusted 
              partner in these regions, connecting top-tier talent with global employment opportunities.
            </p>

            <div className="bg-cyan-50 rounded-2xl p-8 mb-8">
              <h3 className="text-2xl font-bold text-navy-900 mb-6 flex items-center">
                <Scale className="h-6 w-6 text-cyan-600 mr-3" />
                Regional Collaborations
              </h3>
              
              <div className="space-y-8">
                {collaborations.map((collab, index) => (
                  <div key={index} className="border-l-4 border-cyan-600 pl-6">
                    <h4 className="text-xl font-bold text-navy-900 mb-2">{collab.region} Collaboration</h4>
                    <div className="mb-3">
                      <p className="font-semibold text-cyan-600">{collab.partner}</p>
                      <p className="text-sm text-gray-600 flex items-center">
                        <MapPin className="h-4 w-4 mr-1" />
                        {collab.location}
                      </p>
                    </div>
                    <p className="text-gray-600 leading-relaxed">{collab.description}</p>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-navy-900 text-white rounded-2xl p-8">
              <h3 className="text-xl font-bold mb-4">Contact Our Recruitment Team</h3>
              <div className="flex items-center space-x-3">
                <div className="bg-cyan-600 p-2 rounded-lg">
                  <Users className="h-5 w-5" />
                </div>
                <div>
                  <p className="font-medium">recruitment@workforceinternational.agency</p>
                  <p className="text-sm text-gray-300">Direct recruitment inquiries</p>
                </div>
              </div>
            </div>
          </div>

          <div className="space-y-8">
            <img 
              src="https://images.pexels.com/photos/3184291/pexels-photo-3184291.jpeg?auto=compress&cs=tinysrgb&w=800"
              alt="Professional team collaboration"
              className="rounded-2xl shadow-lg"
            />
            
            <div className="bg-cyan-50 rounded-2xl p-8">
              <h3 className="text-2xl font-bold text-navy-900 mb-6">Our Core Values</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                {values.map((value, index) => (
                  <div key={index} className="flex items-start space-x-3">
                    <div className="bg-cyan-600 text-white p-2 rounded-lg flex-shrink-0">
                      {value.icon}
                    </div>
                    <div>
                      <h4 className="font-semibold text-navy-900 mb-1">{value.title}</h4>
                      <p className="text-sm text-gray-600">{value.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-green-50 border border-green-200 rounded-2xl p-8">
              <h3 className="text-xl font-bold text-navy-900 mb-4">Our Commitment</h3>
              <p className="text-gray-600 leading-relaxed">
                Through these key collaborations, we ensure that all legal matters surrounding 
                international labour and recruitment are thoroughly explored, fostering ethical 
                recruitment practices and securing the rights of both employers and job seekers.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;