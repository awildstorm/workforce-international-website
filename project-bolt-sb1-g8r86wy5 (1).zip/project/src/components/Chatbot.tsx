import React, { useState } from 'react';
import { MessageCircle, X, Send, Bot, User } from 'lucide-react';

interface Message {
  id: number;
  text: string;
  isBot: boolean;
  timestamp: Date;
}

const Chatbot: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 1,
      text: "Hello! I'm here to help you with questions about our services, costs, job categories, and application process. How can I assist you today?",
      isBot: true,
      timestamp: new Date()
    }
  ]);
  const [inputText, setInputText] = useState('');

  const faqResponses: { [key: string]: string } = {
    'cost': 'Our registration cost is USD 50. This is a one-time payment for processing your application.',
    'fee': 'Our registration cost is USD 50. This is a one-time payment for processing your application.',
    'price': 'Our registration cost is USD 50. This is a one-time payment for processing your application.',
    'payment': 'You can pay via M-Pesa (Till Number: 493969), bank transfer, online payment, or Western Union. The registration cost is USD 50.',
    'mpesa': 'To pay via M-Pesa: Go to Lipa na M-Pesa → Buy Goods → Pay USD 50 to Till Number 493969. Keep your confirmation code for verification.',
    'requirements': 'Requirements vary by job category. For example, Front Office Staff need excellent communication skills, computer literacy (MS Office), professional appearance, and minimum 1 year customer service experience.',
    'jobs': 'We offer positions in Front Office Staff, Healthcare Professionals, IT Specialists, Construction Workers, and Hospitality Staff. Click on any category to see detailed requirements.',
    'apply': 'To apply, choose your job category, meet the basic criteria, pay the USD 50 registration cost, and submit your application with required documents.',
    'contact': 'You can reach us at recruitment@workforceinternational.agency or through our contact form. Our office is at 724 Lexington Avenue, New York, NY 10022, United States.',
    'location': 'Our main office is located at 724 Lexington Avenue, New York, NY 10022, United States.',
    'regions': 'We specialize in workforce solutions across Asia, East, and Central Africa, with legal partnerships in Bhutan and Kenya.'
  };

  const getBotResponse = (userMessage: string): string => {
    const lowerMessage = userMessage.toLowerCase();
    
    for (const [keyword, response] of Object.entries(faqResponses)) {
      if (lowerMessage.includes(keyword)) {
        return response;
      }
    }
    
    return "Thank you for your question. A member of our support team will get back to you shortly with detailed information.";
  };

  const handleSendMessage = () => {
    if (!inputText.trim()) return;

    const userMessage: Message = {
      id: messages.length + 1,
      text: inputText,
      isBot: false,
      timestamp: new Date()
    };

    const botResponse: Message = {
      id: messages.length + 2,
      text: getBotResponse(inputText),
      isBot: true,
      timestamp: new Date()
    };

    setMessages([...messages, userMessage, botResponse]);
    setInputText('');
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSendMessage();
    }
  };

  return (
    <>
      {/* Chat Button */}
      <button
        onClick={() => setIsOpen(true)}
        className={`fixed bottom-6 right-6 bg-cyan-600 text-white p-4 rounded-full shadow-lg hover:bg-cyan-700 transition-all duration-300 z-50 ${isOpen ? 'hidden' : 'block'}`}
      >
        <MessageCircle className="h-6 w-6" />
      </button>

      {/* Chat Window */}
      {isOpen && (
        <div className="fixed bottom-6 right-6 w-96 h-96 bg-white rounded-2xl shadow-2xl border border-gray-200 z-50 flex flex-col">
          {/* Header */}
          <div className="bg-navy-900 text-white p-4 rounded-t-2xl flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="bg-cyan-600 p-2 rounded-full">
                <Bot className="h-5 w-5" />
              </div>
              <div>
                <h3 className="font-semibold">AI Assistant</h3>
                <p className="text-sm text-gray-300">Online now</p>
              </div>
            </div>
            <button
              onClick={() => setIsOpen(false)}
              className="text-gray-300 hover:text-white transition-colors"
            >
              <X className="h-5 w-5" />
            </button>
          </div>

          {/* Messages */}
          <div className="flex-1 p-4 overflow-y-auto space-y-4">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex ${message.isBot ? 'justify-start' : 'justify-end'}`}
              >
                <div className={`flex items-start space-x-2 max-w-xs ${message.isBot ? '' : 'flex-row-reverse space-x-reverse'}`}>
                  <div className={`p-2 rounded-full ${message.isBot ? 'bg-cyan-100 text-cyan-600' : 'bg-navy-100 text-navy-900'}`}>
                    {message.isBot ? <Bot className="h-4 w-4" /> : <User className="h-4 w-4" />}
                  </div>
                  <div
                    className={`p-3 rounded-lg ${
                      message.isBot
                        ? 'bg-gray-100 text-gray-800'
                        : 'bg-cyan-600 text-white'
                    }`}
                  >
                    <p className="text-sm">{message.text}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Input */}
          <div className="p-4 border-t border-gray-200">
            <div className="flex space-x-2">
              <input
                type="text"
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder="Type your message..."
                className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-cyan-500 focus:border-transparent text-sm"
              />
              <button
                onClick={handleSendMessage}
                className="bg-cyan-600 text-white p-2 rounded-lg hover:bg-cyan-700 transition-colors"
              >
                <Send className="h-4 w-4" />
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default Chatbot;