import React, { useState } from 'react';
import { ChevronDown, ChevronUp, Briefcase, Users, Monitor, Star, UserCheck } from 'lucide-react';

interface JobCategory {
  title: string;
  icon: React.ReactNode;
  criteria: string[];
}

const JobCategories: React.FC = () => {
  const [expandedCategory, setExpandedCategory] = useState<number | null>(null);

  const jobCategories: JobCategory[] = [
    {
      title: "Front Office Staff",
      icon: <UserCheck className="h-6 w-6" />,
      criteria: [
        "Excellent communication skills",
        "Computer literacy (MS Office)",
        "Professional appearance",
        "Minimum of 1 year of customer service experience"
      ]
    },
    {
      title: "Front Office Staff",
      icon: <UserCheck className="h-6 w-6" />,
      criteria: [
        "Excellent communication skills",
        "Computer literacy (MS Office)",
        "Professional appearance",
        "Minimum of 1 year of customer service experience"
      ]
    },
    {
      title: "Healthcare Professionals",
      icon: <Star className="h-6 w-6" />,
      criteria: [
        "Valid medical license/certification",
        "Minimum 2 years clinical experience",
        "English proficiency",
        "Clean background check"
      ]
    },
    {
      title: "IT Specialists",
      icon: <Monitor className="h-6 w-6" />,
      criteria: [
        "Relevant technical certifications",
        "3+ years programming experience",
        "Problem-solving abilities",
        "Team collaboration skills"
      ]
    },
    {
      title: "Construction Workers",
      icon: <Briefcase className="h-6 w-6" />,
      criteria: [
        "Trade certification or apprenticeship",
        "Physical fitness requirements",
        "Safety training completion",
        "2+ years field experience"
      ]
    },
    {
      title: "Hospitality Staff",
      icon: <Users className="h-6 w-6" />,
      criteria: [
        "Customer service orientation",
        "Language proficiency",
        "Flexibility with schedules",
        "Previous hospitality experience preferred"
      ]
    }
  ];

  const toggleCategory = (index: number) => {
    setExpandedCategory(expandedCategory === index ? null : index);
  };

  return (
    <section id="job-categories" className="py-24 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-20">
          <div className="inline-block bg-cyan-100 text-cyan-600 px-6 py-3 rounded-full text-sm font-bold mb-6 uppercase tracking-wide">
            Job Categories
          </div>
          <h2 className="text-5xl lg:text-6xl font-bold text-navy-900 mb-8">
            Find Your Perfect
            <span className="block text-cyan-600">Career Match</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-4xl mx-auto leading-relaxed">
            Explore our diverse range of job categories and their specific requirements. 
            Click on any category to view detailed criteria.
          </p>
        </div>

        <div className="max-w-5xl mx-auto space-y-6">
          {jobCategories.map((category, index) => (
            <div 
              key={index}
              className="bg-light-gray rounded-2xl shadow-lg overflow-hidden transition-all duration-500 hover:shadow-2xl border border-gray-100"
            >
              <button
                onClick={() => toggleCategory(index)}
                className="w-full px-10 py-8 flex items-center justify-between text-left hover:bg-white transition-colors duration-300"
              >
                <div className="flex items-center space-x-6">
                  <div className="bg-cyan-100 text-cyan-600 p-4 rounded-xl">
                    {category.icon}
                  </div>
                  <h3 className="text-2xl font-bold text-navy-900">{category.title}</h3>
                </div>
                <div className="text-cyan-600">
                  {expandedCategory === index ? (
                    <ChevronUp className="h-7 w-7" />
                  ) : (
                    <ChevronDown className="h-7 w-7" />
                  )}
                </div>
              </button>

              {expandedCategory === index && (
                <div className="px-10 pb-8 bg-white border-t border-gray-200">
                  <div className="pt-8">
                    <h4 className="text-xl font-bold text-navy-900 mb-6">Basic Criteria:</h4>
                    <ul className="space-y-4">
                      {category.criteria.map((criterion, criterionIndex) => (
                        <li 
                          key={criterionIndex}
                          className="flex items-start space-x-4"
                        >
                          <div className="bg-green-100 text-green-600 p-2 rounded-full mt-1">
                            <div className="w-3 h-3 bg-current rounded-full"></div>
                          </div>
                          <span className="text-gray-700 text-lg">{criterion}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>

        <div className="text-center mt-16">
          <div className="bg-gradient-to-r from-cyan-600 to-cyan-700 rounded-3xl p-12 text-white">
            <h3 className="text-3xl font-bold mb-4">Don't See Your Profession?</h3>
            <p className="text-xl text-cyan-100 mb-8 max-w-2xl mx-auto">
              We work across many more categories and are always expanding our opportunities.
            </p>
            <button 
              onClick={() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' })}
              className="bg-white text-cyan-600 px-10 py-4 rounded-xl font-bold text-lg hover:bg-gray-100 transition-colors shadow-lg"
            >
              Contact Us for More Information
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default JobCategories;